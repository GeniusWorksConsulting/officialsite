<form method="get" id="searchform" action="<?php echo home_url(); ?>/">
    <fieldset>
    	<input name="s" type="text" id="s" class="medium" placeholder="<?php _e("Click here to search", "instyle"); ?>">
    </fieldset>
</form>