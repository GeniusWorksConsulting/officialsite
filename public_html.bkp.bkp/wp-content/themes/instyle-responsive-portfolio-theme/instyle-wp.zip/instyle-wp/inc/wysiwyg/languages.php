<?php $strings = "tinyMCE.addI18n({en:{
shortcodes:{desc : 'Add a Custom Shortcode'},}});";
?>